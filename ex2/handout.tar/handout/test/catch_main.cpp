#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main()
#include "catch.hpp"
